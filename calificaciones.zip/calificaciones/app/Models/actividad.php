<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Actividad extends Model
{
    protected $fillable = ['tipo', 'calificacion', 'fecha', 'descripcion'];

    public function materia()
    {
        return $this->belongsTo(Materia::class);
    }
}
